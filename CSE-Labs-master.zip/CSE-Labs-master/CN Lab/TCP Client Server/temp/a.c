#include <stdio.h>
int main () {
	printf("HELLO WORLD!");
}
