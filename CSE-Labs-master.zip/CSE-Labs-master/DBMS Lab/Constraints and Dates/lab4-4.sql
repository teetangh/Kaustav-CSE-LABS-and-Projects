
insert into Department2 values ('1', 'Sniffing', 'NY');
insert into Department2 values ('2', 'Enforcement', 'NY');
insert into Department2 values ('4', 'Admin', 'NY');
insert into Department2 values ('6', 'Field', 'NY');
insert into Department2 values ('9', 'AnalogInterface', 'NY');

insert into Employee values ('001', 'Finch', 'M', '900000', 'Not Determined', '4');
insert into Employee values ('002', 'Reese', 'M', '650000', 'Address 2', '6');
insert into Employee values ('003', 'Shaw', 'F', '650000', 'Address 4', '6');
insert into Employee values ('004', 'Root', 'F', '800000', 'Address 3', '9');
insert into Employee values ('005', 'Fusco', 'M', '500000', 'Address 6', '2');
insert into Employee values ('006', 'Bear', 'M', '200000', 'Address 7', '1');