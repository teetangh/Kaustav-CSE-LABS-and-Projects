select empName, to_char(dob, 'MONTH') from Employee;
select empName, to_char(dob, 'Month') from Employee;