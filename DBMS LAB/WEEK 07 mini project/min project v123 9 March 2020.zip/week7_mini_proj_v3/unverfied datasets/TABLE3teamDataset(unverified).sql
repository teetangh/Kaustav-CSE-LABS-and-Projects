INSERT INTO TEAM VALUES('Football',40,25,5,'02-Jun-17',18098483,'1001');
INSERT INTO TEAM VALUES('Cricket',42,26,6,'03-Jul-18',18096733,'1002');
INSERT INTO TEAM VALUES('Athletics',44,40,7,'04-May-19',18093912,'1003');
INSERT INTO TEAM VALUES('Basketball',46,28,8,'05-Jan-15',18095376,'1004');
INSERT INTO TEAM VALUES('Volleyball',50,29,9,'06-Feb-14',18097056,'1004');


select * from team_member;
select * from outdoor_activities;
select * from team;