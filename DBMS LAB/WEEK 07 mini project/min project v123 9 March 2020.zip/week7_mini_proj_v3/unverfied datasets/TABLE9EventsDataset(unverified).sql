INSERT INTO EVENTS VALUES('5000','Revels','Manipal','Sasikumar','3000');
INSERT INTO EVENTS VALUES('5001','Inter MAHE','Manipal','Manjini','3001');
INSERT INTO EVENTS VALUES('5002','Mood Indigo','Mangalore','Sudhakar','3002');
INSERT INTO EVENTS VALUES('5003','Rivieravit','Vellore','Saravanan','3003');
INSERT INTO EVENTS VALUES('5004','Sportsquake','Chennai','Hemalatha','3003');
