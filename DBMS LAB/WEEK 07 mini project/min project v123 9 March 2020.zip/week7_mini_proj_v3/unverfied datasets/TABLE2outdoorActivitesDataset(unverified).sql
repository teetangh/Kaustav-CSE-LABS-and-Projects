INSERT INTO outdoor_activities VALUES('1000','VIT Vellore','02-Jun-17',7000);
INSERT INTO outdoor_activities VALUES('1001','SRM Chennai','02-Jun-18',8000);
INSERT INTO outdoor_activities VALUES('1002','MUJ Jaipur','02-Jun-19',9000);
INSERT INTO outdoor_activities VALUES('1003','MIT Mangalore','03-May-17',7500);
INSERT INTO outdoor_activities VALUES('1004','KMC Manipal','01-Feb-17',7654);




SELECT * from outdoor_activities;