INSERT INTO Belongs_to VALUES(18098483,'Football');
INSERT INTO Belongs_to VALUES(18091793,'Football');
INSERT INTO Belongs_to VALUES(18096733,'Football');
INSERT INTO Belongs_to VALUES(18095012,'Athleteics');
INSERT INTO Belongs_to VALUES(18092157,'Athleteics');
INSERT INTO Belongs_to VALUES(18093912,'Athleteics');
INSERT INTO Belongs_to VALUES(18098460,'Athleteics');
INSERT INTO Belongs_to VALUES(18092462,'Basketball');
INSERT INTO Belongs_to VALUES(18095719,'Basketball');
INSERT INTO Belongs_to VALUES(18095376,'Volleyball');
INSERT INTO Belongs_to VALUES(18099363,'Volleyball');
INSERT INTO Belongs_to VALUES(18091789,'Volleyball');
INSERT INTO Belongs_to VALUES(18096990,'Cricket');
INSERT INTO Belongs_to VALUES(18097056,'Cricket');

select * from Belongs_to;