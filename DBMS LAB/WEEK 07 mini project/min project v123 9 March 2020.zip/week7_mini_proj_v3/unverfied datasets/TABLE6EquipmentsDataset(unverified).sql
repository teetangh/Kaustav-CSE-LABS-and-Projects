INSERT INTO Equipments VALUES ('football',10);
INSERT INTO Equipments VALUES ('basketball',19);
INSERT INTO Equipments VALUES ('spikes',18);
INSERT INTO Equipments VALUES ('hurdles',17);
INSERT INTO Equipments VALUES ('javelin',19);

SELECT * FROM Equipments;