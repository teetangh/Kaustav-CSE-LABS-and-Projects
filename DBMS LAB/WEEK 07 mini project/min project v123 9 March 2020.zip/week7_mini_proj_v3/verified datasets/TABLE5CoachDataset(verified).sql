INSERT INTO COACH VALUES ('2000','Shridhar',9687568221,'shridhar@gmail.com','02-Jul-17',20000,'Football');
INSERT INTO COACH VALUES ('2001','Govardhan',9844991432,'govardhan@gmail.com','03-May-16',25000,'Athletics');
INSERT INTO COACH VALUES ('2002','Rameshwar',9700449532,'rameshwar@gmail.com','04-Feb-18',30000,'Volleyball');
INSERT INTO COACH VALUES ('2003','Krishna',9890445577,'krishna@gmail.com','05-Jan-18',30000,'Cricket');