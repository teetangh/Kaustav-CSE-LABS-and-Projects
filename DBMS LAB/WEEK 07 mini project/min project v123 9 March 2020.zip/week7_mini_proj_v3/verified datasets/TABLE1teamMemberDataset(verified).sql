-- Correct
INSERT INTO TEAM_MEMBER VALUES(18098483,'Lucina','09-Jun-01','Accounting','M',7566172868,'ladamolid@cisco.com',19,'A+');
INSERT INTO TEAM_MEMBER VALUES(18091793,'Ailbert Pain','29-Apr-91','Business Development','M',8043993294,'apain0@nationalgeographic.com',19,'A+');
INSERT INTO TEAM_MEMBER VALUES(18096733,'Ingaberg Mundell','12-Jul-90','Sales','F',8355554830,'imundell1@wordpress.com',2,'B+');
INSERT INTO TEAM_MEMBER VALUES(18095012,'Mikkel Eliasson','14-Jun-81','Human Resources','M',9879682943,'meliasson2@nyu.edu',18,'AB+');
INSERT INTO TEAM_MEMBER VALUES(18092157,'Vinson Rustan','01-Sep-86','Support','M',8754632940,'vrustan3@plala.or.jp',10,'B-');
INSERT INTO TEAM_MEMBER VALUES(18093912,'Jeni Clorley','21-Jun-89','Business Development','M',9566993911,'jclorley4@shareasale.com',18,'O+');
INSERT INTO TEAM_MEMBER VALUES(18098460,'Albertine Wickardt','01-Jul-84','Legal','F',9360856527,'awickardt5@time.com',22,'O-');
INSERT INTO TEAM_MEMBER VALUES(18092462,'Demetre Hammill','07-Nov-02','Sales','F',9494913119,'dhammill6@shinystat.com',5,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18095719,'Kiley Hackelton','11-Dec-96','Human Resources','F',9067245875,'khackelton7@diigo.com',18,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18095376,'Gary Biasioli','22-Dec-81','Business Development','F',7642205585,'gbiasioli8@about.me',22,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18099363,'Etta Lanchberry','28-Aug-04','Product Management','F',8403033578,'elanchberry9@boston.com',2,'AB+');
INSERT INTO TEAM_MEMBER VALUES(18091789,'Prentiss Rosindill','23-Aug-00','Human Resources','F',9471928206,'prosindilla@opensource.org',15,'O-');
INSERT INTO TEAM_MEMBER VALUES(18096990,'Maryrose Ayce','28-Jun-90','Sales','M',8822414189,'mayceb@creativecommons.org',22,'B-');
INSERT INTO TEAM_MEMBER VALUES(18097056,'Jacqui Peatheyjohns','13-Jun-84','Services','M',7314672500,'jpeatheyjohnsc@imdb.com',15,'A-');
