INSERT INTO Equipments VALUES ('football',60);
INSERT INTO Equipments VALUES ('basketball',69);
INSERT INTO Equipments VALUES ('spikes',78);
INSERT INTO Equipments VALUES ('hurdles',67);
INSERT INTO Equipments VALUES ('javelin',79);
