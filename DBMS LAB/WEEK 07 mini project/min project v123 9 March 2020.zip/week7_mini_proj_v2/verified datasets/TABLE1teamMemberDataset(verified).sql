
-- INSERT INTO TEAM VALUES(reg_no,mem_name,DOB,department,contact_num,email,hostel

INSERT INTO TEAM_MEMBER VALUES(18098483,'Lucina','09-Jun-01','Accounting','M',7566172868,'ladamolid@cisco.com',19,'A+');
INSERT INTO TEAM_MEMBER VALUES(18091793,'Ailbert Pain','29-Apr-91','Business Development','M',8043993294,'apain0@nationalgeographic.com',19,'A+');
INSERT INTO TEAM_MEMBER VALUES(18096733,'Ingaberg Mundell','12-Jul-90','Sales','F',8355554830,'imundell1@wordpress.com',2,'B+');
INSERT INTO TEAM_MEMBER VALUES(18095012,'Mikkel Eliasson','14-Jun-81','Human Resources','M',9879682943,'meliasson2@nyu.edu',18,'AB+');
INSERT INTO TEAM_MEMBER VALUES(18092157,'Vinson Rustan',01-Sep-86','Support','M',8754632940,'vrustan3@plala.or.jp',10,'B-');
INSERT INTO TEAM_MEMBER VALUES(18093912,'Jeni Clorley','21-Jun-89','Business Development','M',9566993911,'jclorley4@shareasale.com',18,'O+');
INSERT INTO TEAM_MEMBER VALUES(18098460,'Albertine Wickardt','01-Jul-84','Legal','F',9360856527,'awickardt5@time.com',22,'O-');
INSERT INTO TEAM_MEMBER VALUES(18092462,'Demetre Hammill','07-Nov-02','Sales','F',9494913119,'dhammill6@shinystat.com',5,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18095719,'Kiley Hackelton','11-Dec-96','Human Resources','F',9067245875,'khackelton7@diigo.com',18,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18095376,'Gary Biasioli','22-Dec-81','Business Development','F',7642205585,'gbiasioli8@about.me',22,'AB-');
INSERT INTO TEAM_MEMBER VALUES(18099363,'Etta Lanchberry','28-Aug-04','Product Management','F',8403033578,'elanchberry9@boston.com',2,'AB+');
INSERT INTO TEAM_MEMBER VALUES(18091789,'Prentiss Rosindill','23-Aug-00','Human Resources','F',9471928206,'prosindilla@opensource.org',15,'O-');
INSERT INTO TEAM_MEMBER VALUES(18096990,'Maryrose Ayce','28-Jun-90','Sales','M',8822414189,'mayceb@creativecommons.org',22,'B-');
INSERT INTO TEAM_MEMBER VALUES(18097056,'Jacqui Peatheyjohns','13-Jun-84','Services','M',7314672500,'jpeatheyjohnsc@imdb.com',15,'A-');



INSERT INTO TEAM VALUES(18097056,'Jacqui Peatheyjohns','13-Jun-84','Services','M',7314672500,'jpeatheyjohnsc@imdb.com',15,'A-');






INSERT INTO TEAM_MEMBER VALUES(18096293,'Carolynn O' Bradain,04-Aug-02,'Research and Development','M',9572684474,'cobradaine@webmd.com',1,'B+');
INSERT INTO TEAM_MEMBER VALUES(18097883,'Cleavland Sego',15-Jan-1982,'Accounting',7380350471,'csegof@nba.com',3);
INSERT INTO TEAM_MEMBER VALUES(18096068,'Stanly Broske',16-Sep-2000,'Services',8045958753,'sbroskeg@bloglines.com',20);
INSERT INTO TEAM_MEMBER VALUES(18099236,'Sanson Storkes',08-Mar-1989,'Research and Development',9313355150,'sstorkesh@histats.com',9);
INSERT INTO TEAM_MEMBER VALUES(18099113,'Dwayne Lawling',22-Sep-1989,'Marketing',8359844947,'dlawlingi@unesco.org',18);
INSERT INTO TEAM_MEMBER VALUES(18093879,'Desiri Gostall',10-Mar-1989,'Legal',9648482846,'dgostallj@msn.com',21);
INSERT INTO TEAM_MEMBER VALUES(18098476,'Dorisa Matelaitis',15-Jan-2000,'Marketing',8962902730,'dmatelaitisk@pbs.org',8);
INSERT INTO TEAM_MEMBER VALUES(18094561,'Drucie Tegeller',01-Jan-1984,'Support',8642526400,'dtegellerl@unicef.org',5);
INSERT INTO TEAM_MEMBER VALUES(18092383,'Olvan Heath',30-Aug-1985,'Training',9123731599,'oheathm@si.edu',8);
INSERT INTO TEAM_MEMBER VALUES(18091807,'Fransisco Brazur',15-Jun-1980,'Business Development',7473173497,'fbrazurn@reddit.com',22);
INSERT INTO TEAM_MEMBER VALUES(18093649,'Haze Hearsey',17-Feb-1982,'Engineering',9208530647,'hhearseyo@fda.gov',20);
INSERT INTO TEAM_MEMBER VALUES(18091241,'Sheryl Cardenosa',19-Oct-1999,'Human Resources',8567106667,'scardenosap@reddit.com',21);
INSERT INTO TEAM_MEMBER VALUES(18091753,'Alexina Hoyes',02-Jul-1981,'Sales',8406618006,'ahoyesq@salon.com',11);
INSERT INTO TEAM_MEMBER VALUES(18094043,'Judah Dust',20-Aug-2002,'Business Development',7224201150,'jdustr@slate.com',10);
INSERT INTO TEAM_MEMBER VALUES(18096935,'Pennie Grgic',03-Jun-1986,'Support',9544342154,'pgrgics@wikimedia.org',7);
INSERT INTO TEAM_MEMBER VALUES(18098106,'Monti Brandassi',17-Mar-1985,'Product Management',8294665345,'mbrandassit@51.la',9);
INSERT INTO TEAM_MEMBER VALUES(18096775,'Lowrance Johns',25-Feb-1998,'Sales',9530021178,'ljohnsu@blogs.com',1);
INSERT INTO TEAM_MEMBER VALUES(18095950,'Garik Barrand',05-Dec-1994,'Services',8874341296,'gbarrandv@marriott.com',6);
INSERT INTO TEAM_MEMBER VALUES(18097665,'Laverna Shoard',10-Aug-1981,'Accounting',7859035755,'lshoardw@soundcloud.com',10);
INSERT INTO TEAM_MEMBER VALUES(18093807,'Nigel Mintrim',11-Aug-1995,'Product Management',8934437948,'nmintrimx@is.gd',19);
INSERT INTO TEAM_MEMBER VALUES(18094546,'Rivkah Sholem',11-Oct-1984,'Legal',7765969428,'rsholemy@thetimes.co.uk',1);
INSERT INTO TEAM_MEMBER VALUES(18098966,'Mildrid Furness',19-Nov-1995,'Support',8427288416,'mfurnessz@java.com',6);
INSERT INTO TEAM_MEMBER VALUES(18098067,'Gun Honeyghan',17-Jul-1982,'Training',9848707591,'ghoneyghan10@com.com',3);
INSERT INTO TEAM_MEMBER VALUES(18099075,'Jere Pugh',18-Sep-1982,'Training',8462216195,'jpugh11@fda.gov',9);
INSERT INTO TEAM_MEMBER VALUES(18091918,'Shelia Hush',15-Apr-2000,'Engineering',8162672472,'shush12@xinhuanet.com',8);
INSERT INTO TEAM_MEMBER VALUES(18092347,'Craggie Sussans',25-Sep-1985,'Research and Development',8405725780,'csussans13@google.pl',3);
INSERT INTO TEAM_MEMBER VALUES(18094790,'Eugene Bird',19-Jul-1982,'Business Development',9475034344,'ebird14@blog.com',1);
INSERT INTO TEAM_MEMBER VALUES(18097817,'Laetitia Lorenzetto',24-Apr-1983,'Sales',9025724874,'llorenzetto15@themeforest.net',18);
INSERT INTO TEAM_MEMBER VALUES(18092467,'Gerri Balazs',13-Dec-2001,'Training',7810170227,'gbalazs16@gmpg.org',11);
INSERT INTO TEAM_MEMBER VALUES(18098664,'Meir Dasent',05-Jun-1985,'Marketing',7829028389,'mdasent17@woothemes.com',11);
INSERT INTO TEAM_MEMBER VALUES(18097142,'Torre MacFarland',27-May-1984,'Engineering',7077754343,'tmacfarland18@buzzfeed.com',2);
INSERT INTO TEAM_MEMBER VALUES(18096617,'Tommie Kollach',25-Jun-1990,'Sales',7683259125,'tkollach19@livejournal.com',2);
INSERT INTO TEAM_MEMBER VALUES(18095064,'Lilah De' Benedetti,01-Apr-1998,'Accounting',8499625076,'lde1a@tinyurl.com',1);
INSERT INTO TEAM_MEMBER VALUES(18097238,'Gaston Hundey',08-Nov-1992,'Marketing',9289036963,'ghundey1b@irs.gov',20);
INSERT INTO TEAM_MEMBER VALUES(18097888,'Kurtis Geator',25-Jan-1982,'Legal',8650239474,'kgeator1c@xing.com',13);
INSERT INTO TEAM_MEMBER VALUES(18092969,'Stanislaus Wildman',11-Oct-2003,'Human Resources',7778750861,'swildman1d@ucoz.ru',22); 