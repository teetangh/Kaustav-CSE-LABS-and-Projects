package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Course {
	private StringProperty courseId;
	
	public void setCourseId(String cid)
	{
		courseId.set(cid);
	}
	
	public String getCourseId()
	{
		return courseId.get();
	}

	public Course(String cid)
	{
		courseId = new SimpleStringProperty(cid);
	}
	
	
	public StringProperty CourseIdProperty() {
		return courseId;
	}
	
}
