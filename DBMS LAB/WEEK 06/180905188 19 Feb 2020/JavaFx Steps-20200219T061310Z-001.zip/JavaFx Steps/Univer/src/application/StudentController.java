package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


import java.sql.*;

public class StudentController {

    @FXML
    private Button btnShow;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtId;
    
    @FXML
    private Button btnNext;


    @FXML
    void next() {
    	try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Course.fxml"));
    		AnchorPane root = (AnchorPane)loader.load();
			
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage stage = new Stage(); 
			CourseController courseController = loader.<CourseController>getController();
			courseController.initData(txtId.getText());
			stage.setScene(scene);
			
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}    
    }

    @FXML
    void show() {
    	try {
    		Class.forName("oracle.jdbc.driver.OracleDriver"); // for server IP address instead of localhost 
    		Connection con;
    		//Database connection
    		con = DriverManager.getConnection(  "jdbc:oracle:thin:@localhost:1521:XE","system","admin");
    		String SQL = "SELECT name from Student where id=" + txtId.getText();// where id=10101";
    		ResultSet rs = con.createStatement().executeQuery(SQL);
    		if(rs.next()) {
    			txtName.setText(rs.getString(1));
    		}
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 
    }       
}