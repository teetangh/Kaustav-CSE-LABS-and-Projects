package application;

import java.sql.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class CourseController {

	private ObservableList<Course> data;
	
	private String studentId;
	
    @FXML
    private Button btnShow;
    
    @FXML
    private TableView<Course> tableView;
    
    
    @FXML
    private TableColumn<Course, String> tblColCourseId;

    
    @FXML
    void onShow() {
    	data = FXCollections.observableArrayList();
    	try {
    		Class.forName("oracle.jdbc.driver.OracleDriver"); // for server IP address instead of localhost 
    		Connection con;
    		//Database connection
    		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
    		String SQL = "SELECT course_id as courseId from Takes where id=" + studentId;// where id=10101";
    		ResultSet rs = con.createStatement().executeQuery(SQL);  	
    		while(rs.next()) {
    			data.add(new Course(rs.getString(1)));
    			//System.out.print(rs.getString(1));
    		}
    		tableView.getItems().clear();
    		tableView.setItems(data);
    		
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	tblColCourseId.setCellValueFactory(new PropertyValueFactory<>("courseId"));
    }
    
    void initData(String id)
    {
    	studentId = id;
    }

}
