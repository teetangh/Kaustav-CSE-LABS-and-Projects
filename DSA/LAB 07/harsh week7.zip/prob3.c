#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct 
{
    char a[20];
    int f,r;
}stc;
char popf(stc *s)
{
    return s->a[s->f++];
}
char popr(stc *s)
{
    return s->a[s->r--];
}
int main()
{
    stc s;
    s.f=0;
    printf("INPUT THE STRING\n");
    scanf("%s",s.a);
    s.r=strlen(s.a)-1;
    while(s.f<s.r)
    {
        if(popr(&s)!=popf(&s))
        {
            printf("NOT PALINDROME\n");
            exit(0);
        }
    }
    printf("PALINDROME\n");
    return 0;
}
