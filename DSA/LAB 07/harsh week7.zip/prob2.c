#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define max 50
typedef struct
{
    char a[max][max];
    int f,r;
}stcq;
int isFull(stcq *s)
{
    int k=(s->r+1)%max;
    return (k==s->f);
}
int isEmpty(stcq *s)
{
    if(s->f==s->r)
    {
        s->f=-1;
        return 1;
    }
    return 0;
}
void pushr(stcq *s,char e[])
{
    if(isFull(s))
    {
        printf("\nSTRING CQ FULL\n");
    }
    else
    {
        s->r=(s->r+1)%max;
        strcpy(s->a[s->r],e);
        if(s->f==-1)
        s->f=0;
    }
}
void pushf(stcq *s,char e[])
{
    if(s->f==0)
    {
        printf("\nSTRING CQ FULL\n");
    }
    else
    {
        s->f=(s->f-1);
        strcpy(s->a[s->f],e);
    }
}
char* pop(stcq *s)
{
    if(s->f==-1)
    {
        printf("\nSTRING CQ EMPTY\n");
        return "ERR";
    }
    else
    {
        int n=isEmpty(s);
        if(s->f==-1)
        {
            return (s->a[s->r]);
        }
        int k=s->f;
        s->f=((s->f+1)%max);
        return (s->a[k]);
    }
}
void display(stcq *s)
{
    if(s->f==-1&&isEmpty(s))
    {
        printf("\nEMPTY CQ\n");
    }
    else
    {
        int i;
        for(i=s->f;(i%max)!=s->r;i++)
        {
            printf("%s ",s->a[(i%max)]);
        }
        printf("%s ",s->a[s->r]);
        printf("\n");
    }
}
int main()
{
    int ch;
    char* e=(char*)calloc(max,sizeof(char));
    stcq *s=(stcq*)malloc(sizeof(stcq));
    s->f=-1;
    s->r=-1;
    int c;
    do
    {
        printf("Enter your choice:\n");
        printf("1.PUSH\t2.POP\t3.DISPLAY\t4.EXIT\n");
        scanf("%d",&ch);
        fflush(stdin);
        switch(ch)
        {
            case 1:
            printf("Input the String to push\n");
            scanf("%s",e);
            fflush(stdin);
            printf("1.PUSH AT R\t2.PUSH AT F\n");
            scanf("%d",&c);
            if(c==1)
            pushr(s,e);
            else
            {
                pushf(s,e);
            }
            break;
            case 2:
            strcpy(e,pop(s));
            if(strcmp(e,"ERR")!=0)
            {
                printf("Removed: %s\n",e);
                if(s->f==-1)
                s->r=-1;
            }
            free(e);
            break;
            case 3:
            display(s);
            break;
            default:
            printf("\nEXIT STATUS INITIATED\n");
            exit(0);
            break;
        }
    }while(ch!=4);
    return 0;
}