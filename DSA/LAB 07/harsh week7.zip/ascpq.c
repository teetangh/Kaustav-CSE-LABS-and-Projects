#include<stdio.h>
#include<stdlib.h>
#define max 50
typedef struct 
{
    int a[max];
    int f,r;
}intq;
void push(intq *s)
{
    if(s->r==max-1)
    {
        printf("\nQUEUE OVERFLOW\n");
        return;
    }
    else
    {
        printf("INPUT THE NUMBER TO INSERT: ");
        int n;
        scanf("%d",&n);
        if(s->f==-1)
        {
            s->f=0;
            s->r=0;
            s->a[s->r]=n;
            return;
        }
        int i=s->f;
        while(s->a[i]<n)
        {
            i++;
        }
        int j;
        s->r+=1;
        for(j=s->r;j>i;j--)
        {
            s->a[j]=s->a[j-1];
        }
        s->a[i]=n;
        return;
    }
}
int pop(intq *s)
{
    if(s->f==-1||s->f>s->r)
    {
        printf("\nEMPTY QUEUE\n");
        return -9999;
    }
    else
    {
        return s->a[s->f++];
    }
}
void display(intq *s)
{
    int i;
    if(s->f==-1||s->f>s->r)
    {
        printf("\nEMPTY QUEUE\n");
        return;
    }
    printf("\nQUEUE ELEMENTS\n");
    for(i=s->f;i<=s->r;i++)
    {
        printf("%d ",s->a[i]);
    }
    printf("\n");
}
int main()
{
    int ch;
    int f;
    intq s;
    s.f=-1;
    s.r=-1;
    do
    {
        printf("INPUT YOUR CHOICE:\n");
        printf("1.PUSH\t2.POP\t3.DISPLAY\t4.EXIT\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:
            push(&s);
            break;
            case 2:
            f=pop(&s);
            if(f!=-9999)
            {
                printf("REMOVED: %d\n",f);
            }
            break;
            case 3:
            display(&s);
            break;
            default:
            exit(0);
        }
    }while(ch!=4);
    return 0;
}