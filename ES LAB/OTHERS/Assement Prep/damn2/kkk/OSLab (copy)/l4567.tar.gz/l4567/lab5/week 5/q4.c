#include <pthread.h>
#include <stdio.h>

void * generate_even_sum(void * array){
	int * arr_int = (int *)array;
	int n = arr_int[0], sum = 0;
	for(int i=1; i<=n; i++)
		sum += (arr_int[i]%2) ? 0 : arr_int[i];
	pthread_exit((void *)sum);
}

void * generate_odd_sum(void * array){
	int * arr_int = (int *)array;
	int n = arr_int[0], sum = 0;
	for(int i=1; i<=n; i++)
		sum += (arr_int[i]%2) ? arr_int[i] : 0;
	pthread_exit((void *)sum);
}

int main(int argc, char const *argv[])
{
	pthread_t thread_even, thread_odd;
	int n;
	void *even_sum, *odd_sum;
	printf("Enter size of array : ");
	scanf("%d", &n);
	int arr[n+1];
	arr[0] = n;
	printf("Enter array elements : ");
	for(int i=1; i<=n; i++)
		scanf("%d", &arr[i]);
	pthread_create(&thread_even,NULL,&generate_even_sum,(void *)arr);
	pthread_join(thread_even, (void**)&even_sum);
	pthread_create(&thread_odd,NULL,&generate_odd_sum,(void *)arr);
	pthread_join(thread_odd, (void**)&odd_sum);
	printf("Even sum = %d\n", (int)even_sum);
	printf("Odd sum = %d\n", (int)odd_sum);
	return 0;
}
