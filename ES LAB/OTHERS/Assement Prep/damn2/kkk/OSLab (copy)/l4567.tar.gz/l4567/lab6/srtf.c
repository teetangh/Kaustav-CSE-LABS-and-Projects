#include <stdio.h>
#include <stdlib.h>
#define MAX 16000

void swap(int *a,int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void sort(int burst[],int at[],int n)
{
    int i,j;
    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(at[j]>at[j+1])
            {
                swap(&at[j],&at[j+1]);
                swap(&burst[j],&burst[j+1]);
            }
}

int new_process(int n,int at[],int bt[],int timer,int completed[])
{
    int i=0,min=MAX,pos;
    while(i<n)
    {
        if(bt[i]<min && completed[i]==0 && timer>=at[i])
        {
            min=bt[i];
            pos=i;
        }
        i++;
    }
    return pos;
}

void simulationSRTF(int n,int bt[],int wt[],int at[],int tat[])
{
    int timer=0,pr_id,num=n,*completed,i;
    int s=-1;
    completed = (int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        completed[i]=0;
    pr_id = new_process(n,at,bt,timer,completed);
    while(num>0)
    {
        timer+=1;
        bt[pr_id]-=1;
        for(i=0;i<n;i++)
            if(i!=pr_id && timer>at[i] && completed[i]==0)
                wt[i]+=1;
        for(i=0;i<n;i++)
            if(timer>at[i] && completed[i]==0)
                tat[i]+=1;
        if(bt[pr_id]==0)
        {
            num-=1;
            completed[pr_id]=1;
            printf("Process %d completed at timer %d\n",pr_id+1,timer);
        }
        
        if(num==0)
            break;
        pr_id = new_process(n,at,bt,timer,completed);
        if(s!=pr_id)
        {
        printf("Executing process %d from time %d\n",pr_id+1,timer);
        s=pr_id;
        }
    }

}

void findavgTime(int n,int bt[],int at[])
{  
    int *wt,*burst,*tat,total_wt = 0, total_tat = 0,i;
    wt = (int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        wt[i]=0;
    sort(bt,at,n);
    burst = (int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        burst[i]=bt[i];
    tat = (int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        tat[i]=0;
    simulationSRTF(n,burst,wt,at,tat);
    printf("Processes    Burst time   Arrival Time");
    printf("     Waiting time   Turn around time\n");
    for (int  i=0; i<n; i++)  
    {
        total_wt = total_wt + wt[i];
        total_tat = total_tat + tat[i];  
        printf("   P%d  ",i+1);
        printf("\t\t %d", bt[i]);
        printf("\t\t%d",at[i]);
        printf("\t\t%d",wt[i]);
        printf("\t\t%d",tat[i]);
        printf("\n");
    }
    printf("\n");
    float s= (float)total_wt / n;
    float t= (float)total_tat / n;
    printf("Average waiting time = %f\n",s);
    printf("Average turn around time = %f\n",t);
}

int main()  
{
    int i,num,*burst,*arrival;
    printf("Enter number of processes : ");
    scanf("%d",&num);
    burst = (int*)malloc(num*sizeof(int));
    arrival = (int*)malloc(num*sizeof(int));
    printf("Enter the burst time for all process : \n");
    for(i=0;i<num;i++)
        scanf("%d",&burst[i]);
    printf("Enter the arrival time for all process : \n");
    for(i=0;i<num;i++)
        scanf("%d",&arrival[i]);
    printf("\n");
    findavgTime(num,burst,arrival);
    return 0;
}