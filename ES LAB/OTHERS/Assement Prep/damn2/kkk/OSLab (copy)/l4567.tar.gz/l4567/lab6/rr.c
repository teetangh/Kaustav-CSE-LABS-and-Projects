#include <stdio.h>
#include <stdlib.h>


void swap(int *a,int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void sort(int at[],int bqueue[],int n)
{
	int i,j;
	for(i=0;i<n-1;i++)
		for(j=0;j<n-i-1;j++)
			if(at[j]>at[j+1])
			{
				swap(&at[j],&at[j+1]);
				swap(&bqueue[j],&bqueue[j+1]);
			}
}

void simulationRR(int bqueue[],int at[],int tat[],int wt[],int n,int q)
{
	int timer=0,num=n,exec_p,k=0,i,q_t=0;
	int *completed = (int*)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
		completed[i] = 0;
	while(num>0)
	{
		exec_p = k;
		timer+=1;
		q_t++;
		bqueue[exec_p]-=1;
		for(i=0;i<n;i++)
			if(i!=exec_p && completed[i]==0 && timer>at[i])
				wt[i]+=1;
		for(i=0;i<n;i++)
			if(completed[i]==0 && timer>at[i])
				tat[i]+=1;
		if(bqueue[exec_p]==0)
		{
			completed[exec_p] = 1;
			i=k;
			k+=1;
			for(;k!=i;k++)
			{
				if(k==n)
				{
					k=-1;
					continue;
				}
				if(completed[k]==0)
					break;
			}
			printf("Process %d completed at %d\n",exec_p+1,timer);
			num-=1;
			q_t=0;
		}
		else if(q_t%q==0)
		{
			i=k;
			k+=1;
			for(;k!=i;k++)
			{
				if(k==n)
				{
					k=-1;
					continue;
				}
				if(completed[k]==0)
					break;	
			}
			if(k!=exec_p)
				printf("Context switching from %d to %d at %d\n",exec_p+1,k+1,timer);
			q_t=0;
		}
	}
}

void avgTimes(int n,int at[],int bqueue[],int q)
{
	int i,total_wt=0,total_tat=0;
	int *wt = (int*)malloc(n*sizeof(int));
	int *tat = (int*)malloc(n*sizeof(int));
	int *burst = (int*)malloc(n*sizeof(int));
	sort(at,bqueue,n);
	for(i=0;i<n;i++)
		burst[i] = bqueue[i];
	simulationRR(bqueue,at,tat,wt,n,q);
	printf("Processes    Burst time   Arrival Time");
    printf("     Waiting time   Turn around time\n");
    for (i=0; i<n; i++)  
    {
        total_wt = total_wt + wt[i];
        total_tat = total_tat + tat[i];  
        printf("   P%d  ",i+1);
        printf("\t\t %d", burst[i]);
        printf("\t\t%d",at[i]);
        printf("\t\t%d",wt[i]);
        printf("\t\t%d",tat[i]);
        printf("\n");
    }
    float s= (float)total_wt / n;
    float t= (float)total_tat / n;
    printf("Average waiting time = %f\n",s);
    printf("Average turn around time = %f\n",t);
}

int main(int argc, char const *argv[])
{
	int i,n,q,*at,*burst;
	printf("Enter the number of processes : ");
	scanf("%d",&n);
	at = (int*)malloc(n*sizeof(int));
	burst = (int*)malloc(n*sizeof(int));
	printf("Enter arrival time for all processes : \n");
	for(i=0;i<n;i++)
		scanf("%d",&at[i]);
	printf("Enter burst time for all processes : \n");
	for(i=0;i<n;i++)
		scanf("%d",&burst[i]);
	printf("Enter the time quantum : ");
	scanf("%d",&q);
	avgTimes(n,at,burst,q);
	return 0;
}