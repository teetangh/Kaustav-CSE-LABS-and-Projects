#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include<stdlib.h>
#include <sys/wait.h>

void main()
{
	pid_t pid;
	pid = fork();
	int x;
	int y;
	int z;
	if(pid == -1)
		printf("\nERROR child not created");
	else if (pid == 0) 
	{
		printf("\n I'm the child!");
		x = getpid();
		y= getppid();
		printf("Parent: %d\n",y);
		printf("Child: %d\n",x);
		exit(0);
	}
	else
	{	
		wait(NULL);
		printf("\n I'm the parent!");
	    x=getpid();
		y=getppid();
		printf("Root: %d\n",y);
		printf("Parent: %d\n",x);
	}
}