#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
FILE *fp;
char file[20], ch;
int c=0, w=0, l=0;
printf("Enter name of the file:");
gets(file);
fp=fopen(file,"r");
if(fp==NULL)
printf("\n\nCan't read from the file\nCheck the file name.....");
else
{
while(1)
{
ch=fgetc(fp);
c++; /*Counting characters.*/
if(ch==EOF)
break;
else if(ch==' ')
w++; /*Counting words.*/
else if(ch=='\n')
{
l++; /*Counting lines.*/
w++;
}
}
printf("\n\nNumber of characters in file %s = %d",file, c);
printf("\n\nNumber of words in file %s = %d",file, w);
printf("\n\nNumber of lines in file %s = %d",file, l);
}
fclose(fp);
return(0);
}
