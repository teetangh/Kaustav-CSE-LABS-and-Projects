#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void * thread_code(void * param){
	printf("In thread_code\n");
}

int main(int argc, char const *argv[])
{	
	pthread_t thread;
	pthread_create(&thread, NULL, &thread_code, NULL);
	printf("In main thread\n");
	pthread_join(thread, NULL);
	return 0;
}