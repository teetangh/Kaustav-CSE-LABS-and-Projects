#include<stdio.h>
#include<stdlib.h>

int count=0;

void p1(){

	int i=0;
	for(i=0; i<60; i++){
		count++;
	}
	printf("p1 Executed, count is %d\n",count);
}

void p2(){

	int i=0;
	for(i=0; i<30; i++){
		count++;
	}
	printf("p2 Executed, count is %d\n",count);
}

void p3(){

	int i=0;
	for(i=0; i<40; i++){
		count++;
	}
	printf("p3 Executed, count is %d\n",count);
}

void p4(){

	int i=0;
	for(i=0; i<10; i++){
		count++;
	}
	printf("p4 Executed, count is %d\n",count);
}
int main()
{
	int ctr =0;
	int arr_time[] = {0,3,4,9};
	int turn_around[4];
	int waiting_time[4];

	while(1){

		if(ctr == 0){
			waiting_time[0] = count;
			p1();
			turn_around[0]=count-arr_time[0];
		}
			
		if(ctr == 3){
			waiting_time[1] = count-arr_time[1];
			p2();
			turn_around[1]=count-arr_time[1];  
		}
			                                           			
		if(ctr == 4){
			waiting_time[2] = count-arr_time[2];
			p3();	
			turn_around[2]=count-arr_time[2];
		}
			   	
		if(ctr == 9){
			waiting_time[3] = count-arr_time[3];
			p4();
			turn_around[3]=count-arr_time[3];   
		}	
		ctr++;	
		if(ctr == 10)
			break;	
	}
	int i=0;
	int total =0;
	for(i;i<4;i++){
		total = total + turn_around[i];
	}
	printf("Avg. Turn Around Time: %d\n",total/4);
	total =0;
	for(i=0;i<4;i++){
		total = total + waiting_time[i];
	}
	printf("Avg. Waiting Time: %d\n",total/4);
	return 0;
}

/*p1 Executed, count is 60
p2 Executed, count is 90
p3 Executed, count is 130
p4 Executed, count is 140
Avg. Turn Around Time: 101
Avg. Waiting Time: 66
*/

