#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void * child_thread(void * param){
	int id = (int)param;
	printf("Create thread id : %i\n", id);
	return (void *)id;
}

int main(int argc, char const *argv[])
{
	pthread_t threads[10];
	int return_values[10];

	for(int i=0; i<10; i++)
		pthread_create(&threads[i], NULL, &child_thread, (void *)i);
	for(int i=0; i<10; i++){
		pthread_join(threads[i], (void **)&return_values[i]);
		printf("End thread id : %i\n", return_values[i]);
	}
	return 0;
}
