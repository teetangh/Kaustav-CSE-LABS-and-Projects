#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	char * path = "/home/shivam/Documents/OSLab/lab7/drive-download-20190917T183421Z-001/program2/program2File";
	int arr[4];
	int i ;
	while(1)
	{
		int fd = open(path,O_WRONLY);
		printf("Enter 4 numbers for the producer to produce.Type first as -1 to quit\n");
		for(i=0;i<=3;i++)
		{
			scanf("%d",&arr[i]);
		}
		int x = write(fd,arr,sizeof(arr));
		if(x==-1)
		{
			perror("\n");
			exit(1);
		}
		//printf("No of bytes written %d\n",x);
		if(arr[0]==-1)
		{
			printf("Producer ending now\n");
			close(fd);
			exit(0);
		}
		close(fd);
	}
}